module main( 
   input I0,
   input I1,
   input I2,
   input I3,
   output O 
);
   
   wire wire1;
   wire wire2;
   wire wire3;
   wire wire4;
   wire wire5;

   AND_GATE_3_INPUTS #(.BubblesMask(3'b000)) GATES_1(
      .input1(~I1),
      .input2(~I2),
      .input3(~I3),
      .result(wire1)
   );
   AND_GATE_3_INPUTS #(.BubblesMask(3'b000)) GATES_2(
      .input1(~I0),
      .input2(I2),
      .input3(~I1),
      .result(wire2)
   );
   AND_GATE_3_INPUTS #(.BubblesMask(3'b000)) GATES_3(
      .input1(~I0),
      .input2(I1),
      .input3(I3),
      .result(wire3)
   );
   assign wire4 = I2 & I3;
   assign wire5 = I0 & I2;

   OR_GATE_4_INPUTS #(.BubblesMask(4'h0)) GATES_4(
      .input1(wire1),
      .input2(wire2),
      .input3(wire3),
      .input4(wire4 | wire5),
      .result(O)
   );

   //your verilog code
   
endmodule
