module Testbench;

    reg I0,I1,I2,I3;
    wire O;

    initial begin
        I0 = 0; I1 = 0; I2 = 0; I3 = 0;
        #5;
        I0 = 0; I1 = 0; I2 = 0; I3 = 1;
        #5; 
        I0 = 0; I1 = 0; I2 = 1; I3 = 0;
        #5;
        I0 = 0; I1 = 0; I2 = 1; I3 = 1;
        #5; 
        I0 = 0; I1 = 1; I2 = 0; I3 = 0;
        #5; 
        I0 = 0; I1 = 1; I2 = 0; I3 = 1;
        #5;  
        I0 = 0; I1 = 1; I2 = 1; I3 = 0;
        #5; 
        I0 = 0; I1 = 1; I2 = 1; I3 = 1;
        #5; 
        I0 = 1; I1 = 0; I2 = 0; I3 = 0;
        #5; 
        I0 = 1; I1 = 0; I2 = 0; I3 = 1;
        #5; 
        I0 = 1; I1 = 0; I2 = 1; I3 = 0;
        #5; 
        I0 = 1; I1 = 0; I2 = 1; I3 = 1;
        #5; 
        I0 = 1; I1 = 1; I2 = 0; I3 = 0;
        #5; 
        I0 = 1; I1 = 1; I2 = 0; I3 = 1;
        #5; 
        I0 = 1; I1 = 1; I2 = 1; I3 = 0;
        #5; 
        I0 = 1; I1 = 1; I2 = 1; I3 = 1;
        #5; 
        $finish;
    end

    main dut( 
        .I0(I0),
        .I1(I1),
        .I2(I2),
        .I3(I3),
        .O(O) 
    );

    `ifdef VERILATE
		initial begin
			$dumpfile({`TOP_DIR,"/Testbench.vcd"});
			$dumpvars(0,dut);
			$dumpon;
		end
    `endif
    
endmodule
