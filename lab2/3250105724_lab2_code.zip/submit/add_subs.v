module AddSubers #(
    parameter LENGTH = 32
)(
    input [LENGTH-1:0] a,
    input [LENGTH-1:0] b,
    input do_sub,
    output [LENGTH-1:0] s,
    output c
);
    wire [LENGTH:0] c_in;
    assign c_in[0] = do_sub;
    genvar i;
    generate
        for (i = 0; i < LENGTH; i = i + 1) begin : add_subs
            Adder adder(
                .a(a[i]),
                .b(b[i] ^ do_sub), 
                .c_in(c_in[i]),
                .s(s[i]),
                .c_out(c_in[i+1])
            );
        end
    endgenerate
    assign c = c_in[LENGTH];

endmodule