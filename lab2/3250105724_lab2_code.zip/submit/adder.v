module Adder(
    input a,
    input b,
    input c_in,
    output s,
    output c_out
);
    
    wire s_half, c_half;
    assign s_half = a ^ b;
    assign c_half = a & b;
    assign s = s_half ^ c_in;
    assign c_out = c_half | (s_half & c_in);
    
endmodule 
