module Mux4T1_32(
    input [31:0] I0,
    input [31:0] I1,
    input [31:0] I2,
    input [31:0] I3,
    input [1:0] S,
    output [31:0] O
);

    wire [31:0] O1, O2;
    assign O1 = S[0] ? I1 : I0;
    assign O2 = S[0] ? I3 : I2;
    assign O = S[1] ? O2 : O1;

endmodule

