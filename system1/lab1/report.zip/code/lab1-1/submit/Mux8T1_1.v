module Mux8T1_1( 
   input [7:0] I,
   input [2:0] S,
   output O 
);

   wire O1, O2;
   Mux4T1_1 mux_1(
      .I0(I[0]),
      .I1(I[1]),
      .I2(I[2]),
      .I3(I[3]),
      .S(S[1:0]),
      .O(O1)
   );

   Mux4T1_1 mux_2(
      .I0(I[4]),
      .I1(I[5]),
      .I2(I[6]),
      .I3(I[7]),
      .S(S[1:0]),
      .O(O2)
   );
   
   assign O = (S[2] & O2) | (~S[2] & O1);

endmodule
