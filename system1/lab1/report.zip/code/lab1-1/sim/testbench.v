module Testbench;

    reg [7:0] I;
    reg [2:0] S;
    wire O;

    integer i;
    initial begin
        // test 1:I=0,无论S如何变化，O都应该为0 
        I = 8'b00000000;
        for (i = 0; i < 8; i = i + 1) begin
            S = i[2:0];
            #5;
        end

        // test 2:I=255,无论S如何变化，O都应该为1
        I = 8'b11111111;
        for (i = 0; i < 8; i = i + 1) begin
            S = i[2:0];
            #5;
        end
        
        // test 3:I=8'b10101010),当S为偶数时O应该为0，当S为奇数时O应该为1
        I = 8'b10101010;
        for (i = 0; i < 8; i = i + 1) begin
            S = i[2:0];
            #5;
        end

        // test 4:I=8'b01010101),当S为偶数时O应该为1，当S为奇数时O应该为0
        I = 8'b01010101;
        for (i = 0; i < 8; i = i + 1) begin
            S = i[2:0];
            #5;
        end

        $finish;    
    end

    Mux8T1_1 dut( 
        .I(I),
        .S(S),
        .O(O) 
    );

    `ifdef VERILATE
		initial begin
			$dumpfile({`TOP_DIR,"/Testbench.vcd"});
			$dumpvars(0,dut);
			$dumpon;
		end
    `endif
    
endmodule
